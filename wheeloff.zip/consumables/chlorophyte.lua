
SMODS.Consumable {
    key = 'chlorophyte',
    set = 'mineral',
    pos = { x = 9, y = 0 },
    config = { 
        extra = {
            shop_slots0 = 1   
        } 
    },
    loc_txt = {
        name = 'Chlorophyte',
        text = {
            [1] = 'The shop has {C:attention}+1{} more card slot.'
        }
    },
    cost = 9,
    unlocked = true,
    discovered = false,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.4,
            func = function()
                card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "+"..tostring(1).." Shop Slots", colour = G.C.BLUE})
                
                change_shop_size(1)
                return true
            end
        }))
        delay(0.6)
    end,
    can_use = function(self, card)
        return true
    end
}