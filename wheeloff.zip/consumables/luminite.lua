
SMODS.Consumable {
    key = 'luminite',
    set = 'Spectral',
    pos = { x = 1, y = 1 },
    loc_txt = {
        name = 'Luminite',
        text = {
            [1] = '{E:1}{C:attention}+1{} Joker Slot{}'
        }
    },
    cost = 15,
    unlocked = true,
    discovered = false,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.4,
            func = function()
                card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "+"..tostring(1).." Joker Slot", colour = G.C.DARK_EDITION})
                G.jokers.config.card_limit = G.jokers.config.card_limit + 1
                return true
            end
        }))
        delay(0.6)
    end,
    can_use = function(self, card)
        return true
    end
}