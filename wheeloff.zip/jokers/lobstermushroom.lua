
SMODS.Joker{ --Lobster Mushroom
    key = "lobstermushroom",
    config = {
        extra = {
            ItSpreads = 0,
            SpreadDirection = 0,
            odds = 2,
            odds2 = 5,
            xmult0 = 5,
            odds3 = 3
        }
    },
    loc_txt = {
        ['name'] = 'Lobster Mushroom',
        ['text'] = {
            [1] = 'Gives {X:red,C:white}X5{} {C:red}Mult{}',
            [2] = '{C:green}1 in 3{} chance to {C:red}self-destruct{}',
            [3] = '{C:green}1 in 5{} chance to convert adjacent jokers into itself,',
            [4] = 'ignores Eternal.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = false,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["wheeloffortune_wheeloff_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_wheeloffortune_lobstermushroom')
        local new_numerator2, new_denominator2 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds2, 'j_wheeloffortune_lobstermushroom')
        local new_numerator3, new_denominator3 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds3, 'j_wheeloffortune_lobstermushroom')
        return {vars = {card.ability.extra.ItSpreads, card.ability.extra.SpreadDirection, new_numerator, new_denominator, new_numerator2, new_denominator2, new_numerator3, new_denominator3}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if to_big((card.ability.extra.ItSpreads or 0)) == to_big(1) then
                if SMODS.pseudorandom_probability(card, 'group_0_c1c6c8b0', 1, card.ability.extra.odds2, 'j_wheeloffortune_lobstermushroom', false) then
                    card.ability.extra.SpreadDirection = (card.ability.extra.SpreadDirection) + 1
                    
                end
            elseif (to_big((card.ability.extra.ItSpreads or 0)) == to_big(1) and to_big((card.ability.extra.SpreadDirection or 0)) == to_big(0)) then
                local my_pos = nil
                for i = 1, #G.jokers.cards do
                    if G.jokers.cards[i] == card then
                        my_pos = i
                        break
                    end
                end
                local target_joker = nil
                if my_pos and my_pos > 1 then
                    local joker = G.jokers.cards[my_pos - 1]
                    if true and not joker.getting_sliced then
                        target_joker = joker
                    end
                end
                
                if target_joker then
                    if target_joker.ability.eternal then
                        target_joker.ability.eternal = nil
                    end
                    target_joker.getting_sliced = true
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                            return true
                        end
                    }))
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                end
            elseif to_big((card.ability.extra.ItSpreads or 0)) == to_big(1) then
                local created_joker = false
                if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                    created_joker = true
                    G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_joker' })
                            if joker_card then
                                
                                joker_card:add_sticker('perishable', true)
                            end
                            G.GAME.joker_buffer = 0
                            return true
                        end
                    }))
                end
                return {
                    message = created_joker and localize('k_plus_joker') or nil
                }
            elseif (to_big((card.ability.extra.ItSpreads or 0)) == to_big(1) and to_big((card.ability.extra.SpreadDirection or 0)) == to_big(1)) then
                local my_pos = nil
                for i = 1, #G.jokers.cards do
                    if G.jokers.cards[i] == card then
                        my_pos = i
                        break
                    end
                end
                local target_joker = nil
                if my_pos and my_pos < #G.jokers.cards then
                    local joker = G.jokers.cards[my_pos + 1]
                    if true and not joker.getting_sliced then
                        target_joker = joker
                    end
                end
                
                if target_joker then
                    if target_joker.ability.eternal then
                        target_joker.ability.eternal = nil
                    end
                    target_joker.getting_sliced = true
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                            return true
                        end
                    }))
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                end
            elseif true then
                if SMODS.pseudorandom_probability(card, 'group_0_3f108f42', 1, card.ability.extra.odds, 'j_wheeloffortune_lobstermushroom', false) then
                    card.ability.extra.ItSpreads = (card.ability.extra.ItSpreads) + 1
                    
                end
            else
                return {
                    Xmult = 5
                }
            end
        end
        if context.after and context.cardarea == G.jokers  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_a7bf6766', 1, card.ability.extra.odds3, 'j_wheeloffortune_lobstermushroom', false) then
                    SMODS.calculate_effect({func = function()
                        local destructable_jokers = {}
                        for i, joker in ipairs(G.jokers.cards) do
                            if joker ~= card and not SMODS.is_eternal(joker) and not joker.getting_sliced then
                                table.insert(destructable_jokers, joker)
                            end
                        end
                        local target_joker = #destructable_jokers > 0 and pseudorandom_element(destructable_jokers, pseudoseed('destroy_joker')) or nil
                        
                        if target_joker then
                            target_joker.getting_sliced = true
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                    return true
                                end
                            }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                        end
                        return true
                    end}, card)
                end
            else
                return {
                    func = function()
                        card.ability.extra.ItSpreads = 0
                        return true
                    end
                }
                return {
                    func = function()
                        card.ability.extra.SpreadDirection = 0
                        return true
                    end
                }
            end
        end
    end
}